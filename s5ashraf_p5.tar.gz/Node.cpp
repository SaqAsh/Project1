#include "Node.h"

Node::Node(TimeSeries* data, Node* next) : data(data), next(next) {
} 